<script setup></script>
<template>
  <section id="welcome" class="py-5 container text-center">
    <h1 class="">Why Choose Us?</h1>
    <!-- Grid -->
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 shadow mt-5">
      <div class="col p-5 border">
        <h2>Efficient Event Planning</h2>
        <p>
          Streamlined planning processes that save time and ensure nothing is
          overlooked.
        </p>
      </div>
      <div class="col p-5 border">
        <h2>Expert Team</h2>
        <p>
          Skilled professionals with years of experience delivering high-quality
          events.
        </p>
      </div>
      <div class="col p-5 border">
        <h2>Cost-Effective Solutions</h2>
        <p>
          Smart budgeting and resource management to maximize your investment.
        </p>
      </div>
      <div class="col p-5 border">
        <h2>On-Time Execution</h2>
        <p>
          Reliable scheduling and coordination to ensure your event runs
          smoothly and on time.
        </p>
      </div>
      <div class="col p-5 border">
        <h2>High Customer Satisfaction</h2>
        <p>
          We prioritize your needs and consistently deliver experiences that
          exceed expectations.
        </p>
      </div>
      <div class="col p-5 border">
        <h2>Strong Communication</h2>
        <p>
          Clear, consistent updates throughout the planning process for full
          transparency.
        </p>
      </div>
    </div>
  </section>
</template>
<style scoped></style>
