<template>
  <section class="overview">
    <h2>Welcome to Insight Hire!</h2>
    <p>
      Insight Hire is your personalized job exploration hub, where you can
      browse a wide range of career opportunities tailored to students and early
      professionals in the tech industry. Whether you're looking for
      internships, part-time roles, or full-time positions, our curated list
      helps you discover the right match for your skills and interests.
    </p>
    <p>
      On the left, you'll find a list of job openings categorized by field and
      position level. Click on any job ID to view detailed information about the
      role, required skills, and how to apply. Each listing includes insights
      into company expectations, supervisor contacts, and available positions.
    </p>
    <p>
      Not sure where to begin? Start by exploring your interests and comparing
      different roles to find the best fit. Insight Hire is designed to make
      your job search efficient, informed, and empowering.
    </p>
  </section>
</template>

<style scoped>
.overview {
  line-height: 1.6;
}
</style>
